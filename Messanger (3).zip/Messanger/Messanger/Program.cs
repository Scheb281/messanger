﻿using Microsoft.Extensions.FileProviders;
using System.Collections.Concurrent;
using System.Net.WebSockets;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://0.0.0.0:5000");

var app = builder.Build();
var sockets = new ConcurrentDictionary<Guid, WebSocket>();

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(Path.Combine(builder.Environment.ContentRootPath, "js")),
    RequestPath = "/js"
});
app.UseWebSockets(new WebSocketOptions
{
    KeepAliveInterval = TimeSpan.FromMinutes(5)
});
async Task HandleWebSocketConnection(WebSocket webSocket)
{
    var buffer = new byte[1024 * 4];
    while (webSocket.State == WebSocketState.Open)
    {
        var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
        if (result.MessageType == WebSocketMessageType.Close) break;

        foreach (var client in sockets.Values.Where(s => s.State == WebSocketState.Open))
        {
            await client.SendAsync(new ArraySegment<byte>(buffer, 0, result.Count), result.MessageType, true, CancellationToken.None);
        }
    }
}

app.MapGet("/", async () =>
{
    var html = await File.ReadAllTextAsync(@"HTML\\MainMenu.html");
    return Results.Content(html, "text/html; charset=utf-8");
});

app.MapGet("/enter", async () =>
{
    var html = await File.ReadAllTextAsync(@"HTML\\Socket.html");
    return Results.Content(html, "text/html; charset=utf-8");
});

app.Map("/ws", async context =>
{
    if (!context.WebSockets.IsWebSocketRequest)
    {
        context.Response.StatusCode = StatusCodes.Status400BadRequest;
        await context.Response.WriteAsync("Expected a WebSocket request.");
        return;
    }

    using var webSocket = await context.WebSockets.AcceptWebSocketAsync();
    var id = Guid.NewGuid();
    sockets.TryAdd(id, webSocket);
    await HandleWebSocketConnection(webSocket);
    sockets.TryRemove(id, out _);
});

await app.RunAsync();