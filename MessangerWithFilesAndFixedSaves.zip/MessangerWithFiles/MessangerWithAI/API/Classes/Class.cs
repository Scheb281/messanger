﻿using Messanger.Classes;
namespace Info.Classes
{
    public class Class
    {
        public static User User { get; set; } = new User();
    }
}
