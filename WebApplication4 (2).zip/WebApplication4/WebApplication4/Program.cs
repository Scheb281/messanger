using System.Net.Http.Json;

var builder = WebApplication.CreateBuilder(args);

// Регистрируем HttpClient, который будет обращаться к Api-проекту
builder.Services.AddHttpClient("ApiClient", client =>
{
    client.BaseAddress = new Uri(builder.Configuration["ApiBaseUrl"]!);
});

var app = builder.Build();

// Раздаём статические файлы из папки wwwroot (там лежит chat.html)
app.UseStaticFiles();

// ─── GigaChat: страница с двумя текст-боксами вызывает этот эндпоинт ──────────

// POST /gigachat — основной сайт пересылает вопрос в Api, Api идёт в GigaChat
app.MapPost("/gigachat", async (GigaChatRequest request, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var response = await client.PostAsJsonAsync("/api/gigachat", request);

    if (!response.IsSuccessStatusCode)
        return Results.Problem("Api вернул ошибку: " + response.StatusCode);

    var result = await response.Content.ReadFromJsonAsync<GigaChatResponse>();
    return Results.Ok(result);
});

// ─── Примеры эндпоинтов основного сайта, которые вызывают Api ────────────────

// GET /products — получить все товары через Api
app.MapGet("/products", async (IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var products = await client.GetFromJsonAsync<List<Product>>("/api/products");
    return Results.Ok(products);
});

// GET /products/{id} — получить один товар через Api
app.MapGet("/products/{id}", async (int id, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var response = await client.GetAsync($"/api/products/{id}");

    if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
        return Results.NotFound();

    var product = await response.Content.ReadFromJsonAsync<Product>();
    return Results.Ok(product);
});

// POST /products — создать товар через Api
app.MapPost("/products", async (CreateProductRequest request, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var response = await client.PostAsJsonAsync("/api/products", request);
    var created = await response.Content.ReadFromJsonAsync<Product>();
    return Results.Ok(created);
});

// PUT /products/{id} — изменить товар через Api
app.MapPut("/products/{id}", async (int id, UpdateProductRequest request, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var response = await client.PutAsJsonAsync($"/api/products/{id}", request);

    if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
        return Results.NotFound();

    var updated = await response.Content.ReadFromJsonAsync<Product>();
    return Results.Ok(updated);
});

// DELETE /products/{id} — удалить товар через Api
app.MapDelete("/products/{id}", async (int id, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var response = await client.DeleteAsync($"/api/products/{id}");

    if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
        return Results.NotFound();

    return Results.NoContent();
});

// GET /ping-api — проверить, отвечает ли Api-проект
app.MapGet("/ping-api", async (IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var result = await client.GetStringAsync("/api/ping");
    return Results.Ok($"Ответ от Api: {result}");
});

app.Run();

// ─── Локальные модели (зеркало моделей из Api-проекта) ───────────────────────

class GigaChatRequest
{
    public string Prompt { get; set; } = "";
}

class GigaChatResponse
{
    public string Answer { get; set; } = "";
}

class Product
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public int Price { get; set; }
}

class CreateProductRequest
{
    public string Name { get; set; } = "";
    public int Price { get; set; }
}

class UpdateProductRequest
{
    public string Name { get; set; } = "";
    public int Price { get; set; }
}
