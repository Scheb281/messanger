namespace API.AI
{
    public class AI
    {
        private const string AuthUrl = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth";
        private const string ChatUrl = "https://gigachat.devices.sberbank.ru/api/v1/chat/completions";
        private const string Scope = "GIGACHAT_API_PERS";
        private const string Model = "GigaChat";
        private const string SystemPrompt = "���� ��������� �����, � �� ����������� � ��� ������.";

        private string AuthKey = "MDE5Yzc2YmYtNGI0Yi03YWU1LTk5Y2QtZDAwMzVkZDkyZjIyOjU2ZTI4Nzg0LWNjMTItNDkyOS1hZWE5LTU5YTQ2NWMwNTI0Yg==";

        private static readonly HttpClient Http = new HttpClient(
            new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback =
                    HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
            })
        {
            Timeout = TimeSpan.FromSeconds(60)
        };

        public string Text(string txt) 
        {
            var authRequest = new HttpRequestMessage(HttpMethod.Post, AuthUrl);
            authRequest.Headers.Authorization = new AuthenticationHeaderValue("Basic", AuthKey);
            authRequest.Headers.Add("RqUID", Guid.NewGuid().ToString());
            authRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            authRequest.Content = new StringContent($"scope={Scope}", Encoding.UTF8, "application/x-www-form-urlencoded");

            var authResponse = await Http.SendAsync(authRequest);
            var authJson = await authResponse.Content.ReadAsStringAsync();
            if (!authResponse.IsSuccessStatusCode)
            {
                txt = authJson;
                return txt;
            }

            using var authDoc = JsonDocument.Parse(authJson);
            var accessToken = authDoc.RootElement.GetProperty("access_token").GetString()!;

            var userText = string.IsNullOrWhiteSpace(txt) ? "������" : txt;

            var requestBody = new
            {
                model = Model,
                messages = new[]
                {
                    new
                    {
                        role = "system",
                        content = SystemPrompt
                    },
                    new
                    {
                        role = "user",
                        content = userText
                    }
                },
                stream = false,
                temperature = 0.2,
                max_tokens = 500
            };

            var gigaRequest = new HttpRequestMessage(HttpMethod.Post, ChatUrl);
            gigaRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            gigaRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            gigaRequest.Content = new StringContent(
                JsonSerializer.Serialize(requestBody),
                Encoding.UTF8,
                "application/json");

            var gigaResponse = await Http.SendAsync(gigaRequest);
            var gigaJson = await gigaResponse.Content.ReadAsStringAsync();
            if (!gigaResponse.IsSuccessStatusCode)
            {
                txt = gigaJson;
                return txt;
            }

            using var gigaDoc = JsonDocument.Parse(gigaJson);
            var answer = gigaDoc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString()!;

            txt = answer;
            return txt;
        }
    }
}