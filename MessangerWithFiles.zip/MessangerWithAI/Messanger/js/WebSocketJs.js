﻿(function () {
    // Проверяем поддержку WebSocket
    if (!window.WebSocket) {
        const logArea = document.getElementById('all_message');
        if (logArea) logArea.value = "⚠️ [СИСТЕМА] Ваш браузер не поддерживает WebSocket.\nНевозможно установить матричное соединение.";
        return;
    }

    // Определяем WebSocket адрес (динамически, чтобы корректно работать локально и на хосте)
    let wsProtocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    let wsHost = window.location.host; // включает порт если есть
    let socketUrl = `${wsProtocol}//${wsHost}/ws`;   // стандартный путь для WebSocket (можно изменить под сервер)
    // Если нужен другой путь, то даём возможность, но оставляем /ws наиболее вероятным для сокетов
    // Но предусмотрим: если при запуске будет ошибка, то выведем в лог

    let socket = null;
    let reconnectAttempts = 0;
    const maxReconnect = 5;
    let reconnectTimeout = null;

    const writeArea = document.getElementById('write_message');
    const allMessagesArea = document.getElementById('all_message');
    const sendBtn = document.getElementById('send_message');
    const closeBtn = document.getElementById('close');
    const aiHelpBtn = document.getElementById('aiHelpBtn');
    const statusSpan = document.getElementById('connectionStatus');

    // Функция добавления сообщения в лог (с timestamp в матричном стиле)
    function addMessageToLog(msg, isSystem = false, isError = false) {
        if (!allMessagesArea) return;
        const timestamp = new Date().toLocaleTimeString('ru-RU', { hour12: false });
        let prefix = isSystem ? (isError ? "[⚡ СБОЙ]" : "[🧬 СИСТЕМА]") : "[📨 ПОЛУЧЕНО]";
        if (isSystem && !isError && msg.includes("Отправлено")) prefix = "[📡 ОТПРАВЛЕНО]";
        else if (!isSystem && msg.startsWith(">> Отправлено:")) prefix = "[✅ ЭХО]";

        const formattedMsg = `[${timestamp}] ${prefix} ${msg}`;
        const current = allMessagesArea.value;
        allMessagesArea.value = current ? current + "\n" + formattedMsg : formattedMsg;
        // автоскролл вниз
        allMessagesArea.scrollTop = allMessagesArea.scrollHeight;
    }

    // Обновление статуса
    function updateStatus(connected) {
        if (statusSpan) {
            if (connected) {
                statusSpan.innerHTML = "🟢 СОЕДИНЕНИЕ АКТИВНО";
                statusSpan.style.color = "#aaffcc";
            } else {
                statusSpan.innerHTML = "🔴 РАЗОРВАН / ОЖИДАНИЕ";
                statusSpan.style.color = "#ffaa88";
            }
        }
    }

    // Подключение WebSocket
    function connectWebSocket() {
        if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
            return;
        }

        try {
            socket = new WebSocket(socketUrl);

            socket.onopen = function () {
                addMessageToLog("Канал передачи данных активирован. Соединение с матрицей установлено.", true);
                updateStatus(true);
                reconnectAttempts = 0;
                if (reconnectTimeout) clearTimeout(reconnectTimeout);
                // при успешном подключении можем отправить приветственный сигнал (опционально)
                // socket.send(JSON.stringify({type:"init", client:"matrix_ui"})); - если нужно
            };

            socket.onmessage = function (event) {
                let message = event.data;
                // Пытаемся красиво отобразить JSON, но в любом случае показываем текст
                try {
                    const parsed = JSON.parse(message);
                    if (parsed.message) message = parsed.message;
                    else if (parsed.text) message = parsed.text;
                    else message = JSON.stringify(parsed, null, 0);
                } catch (e) { /* оставляем как есть */ }
                addMessageToLog(message, false);
            };

            socket.onerror = function (error) {
                console.error("WebSocket ошибка:", error);
                addMessageToLog("Обнаружена ошибка канала связи. Попытка переподключения...", true, true);
                updateStatus(false);
            };

            socket.onclose = function (event) {
                let reason = (event.reason ? event.reason : "Неизвестная причина");
                addMessageToLog(`Соединение разорвано (код: ${event.code}) Причина: ${reason}. Переподключение...`, true, true);
                updateStatus(false);
                // Переподключение с задержкой
                if (reconnectAttempts < maxReconnect) {
                    reconnectAttempts++;
                    const delay = Math.min(3000 * reconnectAttempts, 10000);
                    reconnectTimeout = setTimeout(() => {
                        connectWebSocket();
                    }, delay);
                } else {
                    addMessageToLog("❌ Превышено количество попыток переподключения. Обновите страницу вручную.", true, true);
                }
            };
        } catch (e) {
            addMessageToLog(`Критическая ошибка соединения: ${e.message}. Убедитесь что WebSocket сервер запущен на ${socketUrl}`, true, true);
            updateStatus(false);
        }
    }

    // Отправка сообщения
    function sendMessage() {
        if (!writeArea) return;
        const msg = writeArea.value.trim();
        if (!msg) {
            addMessageToLog("Невозможно отправить пустое сообщение. Введите данные.", true, true);
            return;
        }

        if (!socket || socket.readyState !== WebSocket.OPEN) {
            addMessageToLog("Соединение потеряно. Пытаемся восстановить связь... Отправка отложена.", true, true);
            connectWebSocket();
            // после переподключения не отправится автоматически, но предложим повтор
            setTimeout(() => {
                if (socket && socket.readyState === WebSocket.OPEN) {
                    addMessageToLog("Соединение восстановлено, можете отправить сообщение повторно.", true);
                }
            }, 1500);
            return;
        }

        try {
            socket.send(msg);
            addMessageToLog(`Отправлено: ${msg.substring(0, 200)}${msg.length > 200 ? "..." : ""}`, true);
            writeArea.value = ""; // Очищаем поле после отправки
            writeArea.focus();
        } catch (err) {
            addMessageToLog(`Ошибка при отправке: ${err.message}`, true, true);
        }
    }

    // Обработчик кнопки "Помощь ИИ" — генерируем подсказки по матричному сокету (локальный AI assistant vibe)
    async function showAIHelp() {
        if (writeArea && writeArea.value.trim() !== "") {
            const dataToSend = {
                text: writeArea.value
            };
            try {
                const response = await fetch('/remove_errors', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(dataToSend)
                });
                if (!response.ok) {
                    throw new Error(`Ошибка сервера: ${response.status}`);
                }
                const data = await response.json();
                writeArea.value = data.answer;
            }
            catch (error) {
                console.error("Не удалось выполнить запрос:", error);
            }
        }
        else {
            const helpText = `
            █▀▄▀█ █ █▄░▄█ ▄▀█ █▀█ █▄░█
            █░▀░█ █ ░░█ █▀█ █▀▄ █░▀█

            🤖 [MATRIX AI CORE] АКТИВИРОВАН:

            • WebSocket-соединение использует протокол для обмена сообщениями в реальном времени.
            • Чтобы отправить команду / данные — введите текст в верхнем поле и нажмите "ПЕРЕДАТЬ".
            • Все полученные сообщения отображаются в "ЛОГ КАНАЛА".
            • Кнопка "НАЗАД" отправит POST-запрос на /Save — завершит сессию (сохранение данных).
            • Если соединение разорвано, интерфейс автоматически попытается переподключиться до 5 раз.
            • Для успешной работы нужен WebSocket-сервер по адресу: ${socketUrl}
            • Стиль матрицы: символы, неоновая подсветка и анимированный фон "цифровой дождь".
            • Совет: не бойтесь экспериментировать с отправкой JSON, текста или команд.

            💡 Доступные действия: двойной щелчок по логу очищает его (если нужно).
            `;
            addMessageToLog(helpText, true);
            // дополнительно можно вывести в alert но лучше в лог, не навязчиво
            const tempDiv = document.createElement('div');
            tempDiv.style.position = 'fixed';
            tempDiv.style.bottom = '20px';
            tempDiv.style.right = '20px';
            tempDiv.style.backgroundColor = '#031f03';
            tempDiv.style.border = '1px solid #3eff77';
            tempDiv.style.color = '#baffb0';
            tempDiv.style.fontFamily = 'monospace';
            tempDiv.style.padding = '14px 20px';
            tempDiv.style.borderRadius = '16px';
            tempDiv.style.zIndex = '9999';
            tempDiv.style.backdropFilter = 'blur(8px)';
            tempDiv.style.fontSize = '14px';
            tempDiv.style.boxShadow = '0 0 25px #1faa44';
            tempDiv.innerHTML = '🧠 ИИ-ПОМОЩНИК: Подсказки добавлены в лог-терминал.';
            document.body.appendChild(tempDiv);
            setTimeout(() => { tempDiv.style.opacity = '0'; setTimeout(() => tempDiv.remove(), 800); }, 1800);
        }
    }

    // Дополнительно: клик по кнопке Назад также даст мягкое предупреждение (сохраняет стандартное действие формы)
    if (closeBtn) {
        closeBtn.addEventListener('click', function (e) {
            if (socket && socket.readyState === WebSocket.OPEN) {
                // не закрываем сокет принудительно, дадим завершиться странице, но добавим сообщение
                addMessageToLog("Завершение сеанса. WebSocket будет закрыт.", true);
                socket.close(1000, "Пользователь нажал назад");
            }
            // форма отправится сама по method="post" action="/Save"
        });
    }

    // Очистка лога двойным кликом (удобно)
    if (allMessagesArea) {
        allMessagesArea.addEventListener('dblclick', function () {
            if (confirm("🧹 Очистить весь лог сообщений?")) {
                allMessagesArea.value = "[ЛОГ ОЧИЩЕН] — Матрица готова к приёму новых данных.\n";
                addMessageToLog("История сообщений очищена пользователем.", true);
            }
        });
    }

    // Обработчик отправки
    if (sendBtn) sendBtn.addEventListener('click', sendMessage);
    if (aiHelpBtn) aiHelpBtn.addEventListener('click', showAIHelp);

    // Enter в поле ввода: Ctrl+Enter или Shift+Enter не мешает, но для удобства: по Ctrl+Enter отправка
    if (writeArea) {
        writeArea.addEventListener('keydown', function (e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                sendMessage();
            }
            // по желанию можно добавить отправку и без модификатора, но это может мешать переносу строки.
        });
    }

    // Инициализация соединения
    connectWebSocket();

    // Для красоты матрицы — добавляем динамический курсор на поле ввода
    if (writeArea) {
        setInterval(() => {
            if (document.activeElement === writeArea) {
                // стилизация
            }
        }, 100);
    }

    // Если не удалось подключиться — показать в логе подробный адрес
    setTimeout(() => {
        if (!socket || socket.readyState !== WebSocket.OPEN) {
            addMessageToLog(`⚠️ ВНИМАНИЕ: WebSocket не смог подключиться к ${socketUrl}. Убедитесь, что сервер запущен и поддерживает путь /ws`, true, true);
        } else {
            addMessageToLog("✅ Готов к приёму и передаче. Матричный протокол активен.", true);
        }
    }, 800);
})();