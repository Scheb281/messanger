﻿(function () {
    // Проверяем поддержку WebSocket
    if (!window.WebSocket) {
        const logArea = document.getElementById('all_message');
        if (logArea) logArea.value = "⚠️ [СИСТЕМА] Ваш браузер не поддерживает WebSocket.\nНевозможно установить матричное соединение.";
        return;
    }

    // Определяем WebSocket адрес (динамически, чтобы корректно работать локально и на хосте)
    let wsProtocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    let wsHost = window.location.host; // включает порт если есть
    let socketUrl = `${wsProtocol}//${wsHost}/ws`;
    const emojiBtn = document.getElementById("emojiBtn");
    const emojiList = document.getElementById("emojiList");

    let socket = null;
    let reconnectAttempts = 0;
    const maxReconnect = 5;
    let reconnectTimeout = null;


    const writeArea = document.getElementById('write_message');
    const allMessagesArea = document.getElementById('all_message');
    const sendBtn = document.getElementById('send_message');
    const styleArea = document.getElementById('TextStyle');
    const closeBtn = document.getElementById('close');
    const aiHelpBtn = document.getElementById('aiHelpBtn');
    const statusSpan = document.getElementById('connectionStatus');
    const files = document.getElementById('file');


    emojiBtn.addEventListener("click", function (e) {
        e.stopPropagation();
        if (emojiList.style.display === "none") {
            emojiList.style.display = "grid";
        } else {
            emojiList.style.display = "none";
        }
    });
    emojiList.addEventListener("click", function (e) {
        if (e.target.classList.contains("emoji-opt")) {
            writeArea.value += e.target.textContent;
            emojiList.style.display = "none";
            writeArea.focus();
        }
    });
    document.addEventListener("click", function (e) {
        if (!emojiList.contains(e.target) && e.target !== emojiBtn) {
            emojiList.style.display = "none";
        }
    });

    // Функция добавления сообщения в лог (с timestamp в матричном стиле)
    function addMessageToLog(msg, isSystem = false, isError = false) {
        if (!allMessagesArea) return;
        const timestamp = new Date().toLocaleTimeString('ru-RU', { hour12: false });
        let prefix = isSystem ? (isError ? "[⚡ СБОЙ]" : "[🧬 СИСТЕМА]") : "[📨 ПОЛУЧЕНО]";
        if (isSystem && !isError && msg.includes("Отправлено")) prefix = "[📡 ОТПРАВЛЕНО]";
        else if (!isSystem && msg.startsWith(">> Отправлено:")) prefix = "[✅ ЭХО]";
        let formattedMsg = `[${timestamp}] ${prefix} ${msg.replace("Отправлено", "")}`;
        const current = allMessagesArea.value;
        allMessagesArea.value = current ? current + "\n" + formattedMsg : formattedMsg;
        // автоскролл вниз
        allMessagesArea.scrollTop = allMessagesArea.scrollHeight;
    }

    // Обновление статуса
    function updateStatus(connected) {
        if (statusSpan) {
            if (connected) {
                statusSpan.innerHTML = "🟢 СОЕДИНЕНИЕ АКТИВНО";
                statusSpan.style.color = "#aaffcc";
            } else {
                statusSpan.innerHTML = "🔴 РАЗОРВАН / ОЖИДАНИЕ";
                statusSpan.style.color = "#ffaa88";
            }
        }
    }

    // Подключение WebSocket
    function connectWebSocket() {
        if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
            return;
        }

        try {
            socket = new WebSocket(socketUrl);

            socket.onopen = function () {
                addMessageToLog("Канал передачи данных активирован. Соединение с матрицей установлено.", true);
                updateStatus(true);
                reconnectAttempts = 0;
                if (reconnectTimeout) clearTimeout(reconnectTimeout);
                // при успешном подключении можем отправить приветственный сигнал (опционально)
                // socket.send(JSON.stringify({type:"init", client:"matrix_ui"})); - если нужно
            };

            socket.onmessage = function (event) {

                try {
                    const data = JSON.parse(event.data);

                    if (data.type === "message") {

                        if (data.text) {
                            addMessageToLog(data.text);
                        }

                        if (
                            data.files &&
                            Array.isArray(data.files) &&
                            data.files.length > 0
                        ) {
                            addFilesToLog(data.files);
                        }

                        return;
                    }

                } catch (e) {
                    addMessageToLog(event.data);
                }
            };

            socket.onerror = function (error) {
                console.error("WebSocket ошибка:", error);
                addMessageToLog("Обнаружена ошибка канала связи. Попытка переподключения...", true, true);
                updateStatus(false);
            };

            socket.onclose = function (event) {
                let reason = (event.reason ? event.reason : "Неизвестная причина");
                addMessageToLog(`Соединение разорвано (код: ${event.code}) Причина: ${reason}. Переподключение...`, true, true);
                updateStatus(false);
                // Переподключение с задержкой
                if (reconnectAttempts < maxReconnect) {
                    reconnectAttempts++;
                    const delay = Math.min(3000 * reconnectAttempts, 10000);
                    reconnectTimeout = setTimeout(() => {
                        connectWebSocket();
                    }, delay);
                } else {
                    addMessageToLog("❌ Превышено количество попыток переподключения. Обновите страницу вручную.", true, true);
                }
            };
        } catch (e) {
            addMessageToLog(`Критическая ошибка соединения: ${e.message}. Убедитесь что WebSocket сервер запущен на ${socketUrl}`, true, true);
            updateStatus(false);
        }
    }

    files.addEventListener("change", () => {

        for (const file of files.files) {

            addMessageToLog(
                `📁 Выбран файл: ${file.name}`,
                true
            );
        }
    });

    // Отправка сообщения
    async function sendMessage() {

        const msg = writeArea?.value.trim() || "";
        const hasFiles = files && files.files.length > 0;

        if (!msg && !hasFiles) {
            addMessageToLog(
                "Введите сообщение или выберите файл.",
                true,
                true
            );
            return;
        }

        if (!socket || socket.readyState !== WebSocket.OPEN) {
            addMessageToLog(
                "Соединение отсутствует.",
                true,
                true
            );
            return;
        }

        let uploadedFiles = [];

        if (hasFiles) {

            const formData = new FormData();

            for (let i = 0; i < files.files.length; i++) {
                formData.append("files", files.files[i]);
            }

            try {

                const response = await fetch("/processingFile", {
                    method: "POST",
                    body: formData
                });

                console.log("status:", response.status);

                const result = await response.json();

                uploadedFiles = result.downloadUrls || [];

            } catch (err) {

                addMessageToLog(
                    `Ошибка загрузки файлов: ${err.message}`,
                    true,
                    true
                );

                return;
            }
        }

        const payload = {
            type: "message",
            text: msg,
            files: uploadedFiles,
            createdAt: Date.now()
        };

        socket.send(JSON.stringify(payload));

        // Лог отправителя

        if (msg) {
            addMessageToLog(msg + "Отправлено", true);
        }

        if (uploadedFiles.length) {
            addFilesToLog(uploadedFiles, true);
        }

        writeArea.value = "";
        files.value = "";
    }
    function addFilesToLog(urls, sender = false) {
        urls.forEach(url => {

            const fileName =
                decodeURIComponent(
                    url.split('/').pop()
                );

            allMessagesArea.value += `📎 ${fileName}: ${url}\n`;
        });

        allMessagesArea.scrollTop = allMessagesArea.scrollHeight;
    }

    async function showAIHelp() {
        const dataToSend = {
            text: allMessagesArea.value,
            style: styleArea.value
        };
        const response = await fetch('/remove_errors', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dataToSend)
        });
        const data = await response.json();
        allMessagesArea.value = data.Answer;
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', function (e) {
            if (socket && socket.readyState === WebSocket.OPEN) {
                addMessageToLog("Завершение сеанса. WebSocket будет закрыт.", true);
                socket.close(1000, "Пользователь нажал назад");
            }
        });
    }

    if (allMessagesArea) {
        allMessagesArea.addEventListener('dblclick', function () {
            if (confirm("🧹 Очистить весь лог сообщений?")) {
                allMessagesArea.value = "[ЛОГ ОЧИЩЕН] — Матрица готова к приёму новых данных.\n";
                addMessageToLog("История сообщений очищена пользователем.", true);
            }
        });
    }

    if (sendBtn) sendBtn.addEventListener('click', sendMessage);
    if (aiHelpBtn) aiHelpBtn.addEventListener('click', showAIHelp);

    if (writeArea) {
        writeArea.addEventListener('keydown', function (e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                sendMessage();
            }
        });
    }


    connectWebSocket();

    if (writeArea) {
        setInterval(() => {
            if (document.activeElement === writeArea) {
            }
        }, 100);
    }


    setTimeout(() => {
        if (!socket || socket.readyState !== WebSocket.OPEN) {
            addMessageToLog(`⚠️ ВНИМАНИЕ: WebSocket не смог подключиться к ${socketUrl}. Убедитесь, что сервер запущен и поддерживает путь /ws`, true, true);
        } else {
            addMessageToLog("✅ Готов к приёму и передаче. Матричный протокол активен.", true);
        }
    }, 800);
})();