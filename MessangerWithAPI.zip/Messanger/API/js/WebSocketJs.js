﻿const wsProtocol = window.location.protocol === "https:" ? "wss" : "ws";
const socket = new WebSocket(`${wsProtocol}://${window.location.host}/ws`);

const write_message = document.getElementById("write_message");
const send_message = document.getElementById("send_message");
const all_message = document.getElementById("all_message");
const close = document.getElementById("close");


const url = window.location.href;
const parts = window.location.pathname.split('/');
const recipientName = parts[parts.length - 1];
const senderNik = document.getElementById("userNik");

send_message.addEventListener("click", function () {
    const messageText = write_message.value.trim();

    if (messageText !== "" && socket.readyState === WebSocket.OPEN) {
        const payload = {
            to: recipientName,
            from: senderNik,
            text: messageText
        };

        socket.send(JSON.stringify(payload));

        all_message.value += "Вы: " + messageText + "\n";
        write_message.value = "";
    }
});

socket.onmessage = function (event) {
    const a = JSON.parse(event.data);
    if (a.from == a.recipientName) {
        return;
    }
    all_message.value += a.recipientName + ": " + a.text + "\n";
    all_message.scrollTop = all_message.scrollHeight;
};

socket.onclose = function () {
    alert("Соединение закрыто!");
};

close.addEventListener("click", function () {
    socket.close(1000, "Завершение работы");
});