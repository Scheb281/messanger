using Info.Classes;
using Messanger;
using Messanger.Classes;
using Messanger.Tabels;
using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.Hosting.Builder;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.OpenApi;
using Npgsql;
using System.Collections;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Web;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using static System.Runtime.InteropServices.JavaScript.JSType;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient("GigaChat")
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
    });

builder.Services.AddSingleton<GigaChatService>();

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins("http://localhost:5076", "https://localhost:7013")
              .AllowAnyMethod()
              .AllowAnyHeader());
});

var ConnectionString =
    builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Строка подключения 'DefaultConnection' не найдена в конфигурации.");

var databaseConnectionString = CreateConnectionString(ConnectionString);

builder.Services.AddDbContext<Db>(options =>
    options.UseNpgsql(
        databaseConnectionString,
        npgsqlOptions => npgsqlOptions.EnableRetryOnFailure()));

builder.Services.AddRazorPages();

var app = builder.Build();
app.UseCors();
app.MapRazorPages();

app.MapPost("/api/remove_errors", async (TextData text, GigaChatService service) =>
{
    if (text == null || string.IsNullOrWhiteSpace(text.Text))
    {
        return Results.BadRequest("Текст пустой");
    }

    try
    {
        string prompt = $"исправь все ошибки в этом тексте, выдай только сам текст, ничего лишнего не пиши: \"{text.Text}\"";

        string answer = await service.AskAsync(prompt);

        return Results.Ok(new GigaChatResponse(answer));
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка GigaChat: " + ex.Message);
    }
});
app.MapGet("/api/CheckUnique/{login}/{nik}", async (string login, string nik, Db db) =>
{
    var us = await db.Users.FirstOrDefaultAsync(u => u.Login == login || u.Nik == nik);
    if (us is null)
    {
        return Results.NotFound(new { message = "Пользователь не найден" });
    }
    return Results.Ok(us);
});
app.MapGet("/api/CheckNik/{nik}", async (string nik, Db db) => 
{
    var us = await db.Users.FirstOrDefaultAsync(u => u.Nik == nik);
    if (us is null)
    {
        return Results.NotFound(new { message = "Пользователь не найден" });
    }
    return Results.Ok(us);
});
app.MapPost("/api/getUser", async (LogPass user, Db db) =>
{
    var us = await db.Users.FirstOrDefaultAsync(u => u.Login == user.Login && u.Password == user.Password);
    if (us is null)
    {
        return Results.NotFound(new { message = "Пользователь не найден" });
    }
    return Results.Ok(us);
});
app.MapGet("/api/dbTest", async (Db db) =>
{
    try
    {
        NpgsqlConnection connection = new NpgsqlConnection(databaseConnectionString);
        connection.Open();
        return Results.Ok();
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка подключения к базе: " + ex.Message + "\nДетали ошибки: " + ex.StackTrace);
    }
});
app.Run();

static string CreateConnectionString(string ConnectionString)
{
    if (!ConnectionString.StartsWith("postgresql://", StringComparison.OrdinalIgnoreCase) &&
        !ConnectionString.StartsWith("postgres://", StringComparison.OrdinalIgnoreCase))
    {
        return ConnectionString;
    }

    var databaseUri = new Uri(ConnectionString);

    var userInfoParts = databaseUri.UserInfo.Split(':', 2, StringSplitOptions.None);

    if (userInfoParts.Length != 2)
    {
        throw new InvalidOperationException("Не удалось разобрать логин и пароль из URI-строки подключения PostgreSQL.");
    }

    var connectionStringBuilder = new NpgsqlConnectionStringBuilder
    {
        Host = databaseUri.Host,

        Port = databaseUri.IsDefaultPort ? 5432 : databaseUri.Port,

        Database = databaseUri.AbsolutePath.Trim('/'),

        Username = Uri.UnescapeDataString(userInfoParts[0]),

        Password = Uri.UnescapeDataString(userInfoParts[1])
    };

    foreach (var queryPart in databaseUri.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
    {
        var queryPartPieces = queryPart.Split('=', 2, StringSplitOptions.None);

        var key = Uri.UnescapeDataString(queryPartPieces[0]);

        var value = queryPartPieces.Length > 1
            ? Uri.UnescapeDataString(queryPartPieces[1])
            : string.Empty;

        if (key.Equals("sslmode", StringComparison.OrdinalIgnoreCase))
        {
            connectionStringBuilder["SSL Mode"] = value;

            continue;
        }

        if (key.Equals("channel_binding", StringComparison.OrdinalIgnoreCase))
        {
            connectionStringBuilder["Channel Binding"] = value;

            continue;
        }

        connectionStringBuilder[key] = value;
    }

    return connectionStringBuilder.ConnectionString;
}