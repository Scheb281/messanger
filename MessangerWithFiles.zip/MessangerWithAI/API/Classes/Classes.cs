﻿using System.Text.Json;

namespace Messanger.Classes
{
    public class User
    {
        public int Id { get; set; }
        public string Nik { get; set; } = string.Empty;
        public string Login { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Chats { get; set; } = string.Empty;
        public string[] Messages { get; set; } = Array.Empty<string>();
    }

    public record class AddUser(string Nik, string Login, string Password);
    public record class LogPass(string Login, string Password);
    public record class TextData(string Text, string Style);
    public record class GigaChatRequest(string Promt);
    public record class GigaChatResponse(string Answer);

    class GigaChatService
    {
        private readonly IHttpClientFactory _factory;
        private readonly string _authorizationKey;
        private readonly string _scope;

        private string? _accessToken;
        private DateTimeOffset _tokenExpiresAt = DateTimeOffset.MinValue;

        public GigaChatService(IHttpClientFactory factory, IConfiguration config)
        {
            _factory = factory;
            _authorizationKey = config["GigaChat:AuthorizationKey"]!;
            _scope = config["GigaChat:Scope"]!;
        }

        public async Task<string> AskAsync(string prompt)
        {
            string token = await GetAccessTokenAsync();

            var client = _factory.CreateClient("GigaChat");

            var requestBody = new
            {
                model = "GigaChat",
                messages = new[]
                {
                new { role = "user", content = prompt }
            }
            };

            using var message = new HttpRequestMessage(
                HttpMethod.Post,
                "https://gigachat.devices.sberbank.ru/api/v1/chat/completions");
            message.Headers.Add("Authorization", "Bearer " + token);
            message.Content = JsonContent.Create(requestBody);

            var response = await client.SendAsync(message);
            response.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            string answer = doc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString() ?? "";

            return answer;
        }
        private async Task<string> GetAccessTokenAsync()
        {
            if (_accessToken != null && DateTimeOffset.UtcNow < _tokenExpiresAt)
                return _accessToken;

            var client = _factory.CreateClient("GigaChat");

            using var message = new HttpRequestMessage(
                HttpMethod.Post,
                "https://ngw.devices.sberbank.ru:9443/api/v2/oauth");
            message.Headers.Add("Authorization", "Basic " + _authorizationKey);
            message.Headers.Add("RqUID", Guid.NewGuid().ToString());
            message.Content = new FormUrlEncodedContent(new[]
            {
            new KeyValuePair<string, string>("scope", _scope)
        });

            var response = await client.SendAsync(message);
            response.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            var root = doc.RootElement;

            _accessToken = root.GetProperty("access_token").GetString();
            long expiresAtMs = root.GetProperty("expires_at").GetInt64();
            _tokenExpiresAt = DateTimeOffset.FromUnixTimeMilliseconds(expiresAtMs).AddMinutes(-1);

            return _accessToken!;
        }
    }

}
