using API.Classes;
using Info.Classes;
using Messanger;
using Messanger.Classes;
using Messanger.Controllers;
using Messanger.Tabels;
using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.Hosting.Builder;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.OpenApi;
using Npgsql;
using System.Collections;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Web;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins("http://localhost:5076", "https://localhost:7013")
              .AllowAnyMethod()
              .AllowAnyHeader());
});


var ConnectionString =
    builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Строка подключения 'DefaultConnection' не найдена в конфигурации.");

var databaseConnectionString = CreateConnectionString(ConnectionString);

builder.Services.AddDbContext<Db>(options =>
    options.UseNpgsql(
        databaseConnectionString,
        npgsqlOptions => npgsqlOptions.EnableRetryOnFailure()));

builder.Services.AddHttpClient("GigaChat")
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
    });

builder.Services.AddRazorPages();
builder.Services.AddSingleton<GigaChatService>();

var app = builder.Build();
app.MapRazorPages();
app.UseCors();

//app.MapGet("/api/nik", async (Db db) =>
//{
//    var n = await db.Users.FirstOrDefaultAsync(u => u.Nik == Class.User.Nik);
//    string html = $"<h1>{n.Nik}</h1>";
//    return Results.Content(html, "text/html; charset=utf-8");
//});
//app.MapPost("/api/up", async (Db db) =>
//{
//    var n = await db.Users.FirstOrDefaultAsync(u => u.Nik == Class.User.Nik);
//    n.Nik = "test44";
//    string html = $"<h1>{n.Nik}</h1>";
//    await db.SaveChangesAsync();
//    return Results.Content(html, "text/html; charset=utf-8");
//});
//app.MapPost("/api/del", async (Db db) =>
//{
//    var n = await db.Users.FirstOrDefaultAsync(u => u.Nik == Class.User.Nik);
//    db.Remove(n);
//    await db.SaveChangesAsync();
//    string html = "Учетная запись удалена";
//    return Results.Content(html, "text/html; charset=utf-8");
//});

app.MapGet("/api/enter/{log}/{pass}", async (Db db, string log, string pass) =>
{

    string login = log;
    string password = GetHash(pass);

    var user = await db.Users.FirstOrDefaultAsync(u => u.Login == login && u.Password == password);

    return JsonSerializer.Serialize(user);
});

app.MapGet("api/getUser/{nik}", async (Db db, string nik) =>
{
    var user = await db.Users.FirstOrDefaultAsync(u => u.Login == nik);

    return JsonSerializer.Serialize(user);    
});

app.MapPost("api/reg/{log}/{pass}/{nik}/{mes}", async (Db db, string log, string pass, string nik, string[] mes) =>
{
    var us = await db.Users.FirstOrDefaultAsync(u => u.Login == nik);

    if (us is not null || pass.Length < 6)
    {
        return null;
    }

    var user = new User
    {
        Login = log,
        Password = GetHash(pass),
        Nik = nik,
        Messages = mes
    };

    await db.Users.AddAsync(user);

    db.SaveChanges();

    return JsonSerializer.Serialize(user);
});

app.MapPost("/api/gigachat", async (GigaChatRequest request, GigaChatService giga) =>
{
    try
    {
        string answer = await giga.AskAsync(request.Prompt);
        return Results.Ok(new GigaChatResponse { Answer = answer });
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка GigaChat: " + ex.Message);
    }
});

app.Run();

static string CreateConnectionString(string ConnectionString)
{
    if (!ConnectionString.StartsWith("postgresql://", StringComparison.OrdinalIgnoreCase) &&
        !ConnectionString.StartsWith("postgres://", StringComparison.OrdinalIgnoreCase))
    {
        return ConnectionString;
    }

    var databaseUri = new Uri(ConnectionString);

    var userInfoParts = databaseUri.UserInfo.Split(':', 2, StringSplitOptions.None);

    if (userInfoParts.Length != 2)
    {
        throw new InvalidOperationException("Не удалось разобрать логин и пароль из URI-строки подключения PostgreSQL.");
    }

    var connectionStringBuilder = new NpgsqlConnectionStringBuilder
    {
        Host = databaseUri.Host,

        Port = databaseUri.IsDefaultPort ? 5432 : databaseUri.Port,

        Database = databaseUri.AbsolutePath.Trim('/'),

        Username = Uri.UnescapeDataString(userInfoParts[0]),

        Password = Uri.UnescapeDataString(userInfoParts[1])
    };

    foreach (var queryPart in databaseUri.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
    {
        var queryPartPieces = queryPart.Split('=', 2, StringSplitOptions.None);

        var key = Uri.UnescapeDataString(queryPartPieces[0]);

        var value = queryPartPieces.Length > 1
            ? Uri.UnescapeDataString(queryPartPieces[1])
            : string.Empty;

        if (key.Equals("sslmode", StringComparison.OrdinalIgnoreCase))
        {
            connectionStringBuilder["SSL Mode"] = value;

            continue;
        }

        if (key.Equals("channel_binding", StringComparison.OrdinalIgnoreCase))
        {
            connectionStringBuilder["Channel Binding"] = value;

            continue;
        }

        connectionStringBuilder[key] = value;
    }

    return connectionStringBuilder.ConnectionString;
}

static string GetHash(string input)
{
    using var sha = SHA256.Create();
    byte[] bytes = Encoding.UTF8.GetBytes(input);
    byte[] hashBytes = sha.ComputeHash(bytes);

    var sb = new StringBuilder();
    foreach (byte b in hashBytes)
        sb.Append(b.ToString("x2"));

    return sb.ToString();
}

