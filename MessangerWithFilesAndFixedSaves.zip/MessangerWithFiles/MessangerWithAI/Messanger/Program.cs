using Info.Classes;
using Messanger.Classes;
using Messanger.Tabels;
using Microsoft.AspNetCore.CookiePolicy;
using Microsoft.AspNetCore.Hosting.Builder;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.OpenApi;
using Newtonsoft.Json;
using Npgsql;
using System.Collections;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Web;
using System.Xml.Linq;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient("ApiClient", client =>
{
    client.BaseAddress = new Uri(builder.Configuration["ApiBaseUrl"]!);
});

var ConnectionString =
    builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Строка подключения 'DefaultConnection' не найдена в конфигурации.");

var databaseConnectionString = CreateConnectionString(ConnectionString);

builder.Services.AddHttpClient("GigaChat")
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
    });

builder.Services.AddDbContext<Db>(options =>
    options.UseNpgsql(
        databaseConnectionString,
        npgsqlOptions => npgsqlOptions.EnableRetryOnFailure()));


builder.Services.AddRazorPages();

var app = builder.Build();
var sockets = new ConcurrentDictionary<Guid, WebSocket>();
app.MapRazorPages();

string uploadsFolder = Path.Combine(app.Environment.ContentRootPath, "UploadedFiles");
if (!Directory.Exists(uploadsFolder))
{
    Directory.CreateDirectory(uploadsFolder);
}

User2 u = new User2();
User User = null!;
string Nik, Messages = string.Empty;
int Index = -1;

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<Db>();

    await db.Database.EnsureCreatedAsync();
    await CreateTables(db);
}

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(Path.Combine(builder.Environment.ContentRootPath, "js")),
    RequestPath = "/js"
});
app.UseWebSockets(new WebSocketOptions
{
    KeepAliveInterval = TimeSpan.FromMinutes(5)
});
async Task HandleWebSocketConnection(WebSocket webSocket)
{
    var buffer = new byte[1024 * 4];
    while (webSocket.State == WebSocketState.Open)
    {
        try
        {
            var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            if (result.MessageType == WebSocketMessageType.Close)
            {
                Reset();
                break;
            }

            foreach (var client in sockets.Values.Where(s => s.State == WebSocketState.Open))
            {
                var message = JsonConvert.DeserializeObject<MessageWithFilesJson>(Encoding.UTF8.GetString(buffer));
                if (message == null) 
                {
                    Reset();
                    return;
                }
                string message1 = string.Empty;
                if (message.Text != string.Empty || string.IsNullOrEmpty(message.Text))
                {
                    message1 = message.Text.Replace("\0", string.Empty);
                }
                if (message.Files.Count > 0)
                {
                    foreach(var file in message.Files)
                    {
                        message1 += file.Replace("\0", string.Empty);
                    }
                }
                Messages += message1 + '\n';
                if (client == webSocket)
                {
                    continue;
                }
                await client.SendAsync(new ArraySegment<byte>(buffer, 0, result.Count), result.MessageType, true, CancellationToken.None);
            }
        }
        catch
        {
            Reset();
        }
    }
}

app.MapGet("/", async (HttpContext context, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    if (context.Request.Cookies.TryGetValue("Session_id", out var value))
    {
        string[] values = value.Split(':');
        var user = await client.PostAsJsonAsync($"/api/getUser", new LogPass(values[0], values[1]));
        if (user.IsSuccessStatusCode)
        {
            var us = await user.Content.ReadFromJsonAsync<User>();
            SetUser(us!);
            context.Response.Redirect("/chats");
        }
    }
    string html = File.ReadAllText($"HTML\\MainMenu.html");
    return Results.Content(html, "text/html; charset=utf-8");
});

app.MapPost("/", async (HttpContext context) => 
{
    DeleteCookie(context);
    context.Response.Redirect("/");
});

app.MapGet("/enter", () => 
{
    string html = File.ReadAllText($"HTML\\Enter.html");
    return Results.Content(html, "text/html; charset=utf-8");
});
app.MapPost("/enter", async (HttpContext context, IHttpClientFactory factory) => 
{
    var client = factory.CreateClient("ApiClient");
    string html = "";
    var form = await context.Request.ReadFormAsync();

    string login = form["login"]!;
    string password = GetHash(form["password"]!);

    var user = await client.PostAsJsonAsync($"/api/getUser", new LogPass(login, password));

    if (user.StatusCode == System.Net.HttpStatusCode.NotFound)
    {
        html = File.ReadAllText($"HTML\\EnterError.html");
        return Results.Content(html, "text/html; charset=utf-8");
    }
    var us = await user.Content.ReadFromJsonAsync<User>();
    SetUser(us!);
    CreateCookie(login, password, context);

    html = File.ReadAllText($"HTML\\EnterS.html");
    return Results.Content(html, "text/html; charset=utf-8");
});

app.MapGet("/api/download/{fileName}", async (string fileName)=>{
    string? keyString = builder.Configuration["FileEncryption:Key"];
    string? ivString = builder.Configuration["FileEncryption:IV"];

    if (string.IsNullOrEmpty(keyString) || string.IsNullOrEmpty(ivString))
    {
        throw new InvalidOperationException("Ключи шифрования не найдены в конфигурации!");
    }
    byte[] encryptionKey = Convert.FromBase64String(keyString);
    byte[] encryptionIv = Convert.FromBase64String(ivString);

    var filePath = Path.Combine(uploadsFolder, fileName);
    if (!File.Exists(filePath)) return Results.NotFound("Файл не найден");

    var provider = new FileExtensionContentTypeProvider();
    if (!provider.TryGetContentType(filePath, out var contentType))
    {
        contentType = "application/octet-stream";
    }

    Aes aes = Aes.Create();
    aes.Key = encryptionKey;
    aes.IV = encryptionIv;
    var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
    var decryptor = aes.CreateDecryptor();

    var cryptoStream = new CryptoStream(fileStream, decryptor, CryptoStreamMode.Read);

    var originalName = fileName.Substring(fileName.IndexOf('_') + 1);

    return Results.File(cryptoStream, contentType, originalName);
});

app.MapPost("/processingFile", async (HttpRequest request) =>
{
    string? keyString = builder.Configuration["FileEncryption:Key"];
    string? ivString = builder.Configuration["FileEncryption:IV"];
    var form = await request.ReadFormAsync();
    var files = form.Files;

    if (string.IsNullOrEmpty(keyString) || string.IsNullOrEmpty(ivString))
    {
        throw new InvalidOperationException("Ключи шифрования не найдены в конфигурации!");
    }
    byte[] encryptionKey = Convert.FromBase64String(keyString);
    byte[] encryptionIv = Convert.FromBase64String(ivString);

    
    if (files == null || files.Count == 0)
        return Results.BadRequest("Файлы не загружены");

    var downloadUrls = new List<string>();

    try
    {
        foreach (var file in files)
        {
            if (file.Length == 0) continue;

            var uniqueFileName = $"{Guid.NewGuid()}_{file.FileName}";
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (Aes aes = Aes.Create())
            {
                aes.Key = encryptionKey;
                aes.IV = encryptionIv;

                using var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                using var encryptor = aes.CreateEncryptor();
                using var cryptoStream = new CryptoStream(fileStream, encryptor, CryptoStreamMode.Write);

                // Копируем загруженный файл в крипто-поток (он зашифрует его на лету)
                await file.CopyToAsync(cryptoStream);
            }
            var downloadUrl = $"{request.Scheme}://{request.Host}/api/download/{uniqueFileName}";
            downloadUrls.Add(downloadUrl);
        }
        return Results.Ok(new { DownloadUrls = downloadUrls });
    }
    catch (Exception ex)
    {
        return Results.BadRequest(ex.Message);
    }
});
app.MapPost("/remove_errors", async (TextData text, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");

    try
    {
        var getAnswer = await client.PostAsJsonAsync("/api/remove_errors", text);

        if (getAnswer.IsSuccessStatusCode)
        {
            var Answer = await getAnswer.Content.ReadFromJsonAsync<GigaChatResponse>();
            return Results.Ok(Answer);
        }
        else
        {
            var errorContent = await getAnswer.Content.ReadAsStringAsync();
            return Results.Problem($"Ошибка GigaChat: {getAnswer.StatusCode} - {errorContent}");
        }
    }
    catch (Exception ex)
    {
        return Results.Problem($"Внутренняя ошибка сервера: {ex.Message}");
    }
});
app.MapGet("/reg", () =>
{
    string html = File.ReadAllText($"HTML\\Reg.html");
    return Results.Content(html, "text/html; charset=utf-8");
});
app.MapPost("/reg", async (HttpContext context, IHttpClientFactory factory) =>
{
    var client = factory.CreateClient("ApiClient");
    var form = await context.Request.ReadFormAsync();

    string login = form["login"]!;
    string password = GetHash(form["password"]!);
    string nik = form["nik"]!;
    string[] messages = { "New" };

    string html = File.ReadAllText($"HTML\\RegS.html");

    HttpResponseMessage response = await client.GetAsync($"/api/CheckUnique/{login}/{nik}");
    if (response.IsSuccessStatusCode || password.Length < 6)
    {
        html = File.ReadAllText($"HTML\\RegError.html");
        return Results.Content(html, "text/html; charset=utf-8");
    }

    var user = new User
    {
        Login = login,
        Password = password,
        Nik = nik,
        Messages = messages
    };


    var a = await client.PostAsJsonAsync("/api/AddNewUser", new AddUser(nik, login, password));
    if(a.StatusCode == HttpStatusCode.BadRequest)
    {
        html = File.ReadAllText($"HTML\\RegError.html");
        return Results.Content(html, "text/html; charset=utf-8");
    }

    SetUser(user);
    CreateCookie(user.Login, user.Password, context);
    return Results.Content(html, "text/html; charset=utf-8");
});

app.MapGet("/chats", () =>
{
    int i = 0;
    bool Check = true;
    string line;
    string html = """<html>""";
    using (StreamReader sr = new StreamReader($"HTML\\Chats.html"))
    {
        while ((line = sr.ReadLine()!) != null)
        {
            if (i == 278)
            {
                i = 0;
            }
            if (line.Trim() == "<div class=\"username-glow cursor-blink\">UserName</div>")
            {
                line = $"""<div class="username-glow cursor-blink">{User.Nik}</div>""";
            }
            if (line.Trim() == "<div class=\"section-title\">📡 КОНТАКТЫ:</div>")
            {
                if (User.Chats != string.Empty)
                {
                    html += line;
                    string[] lines = User.Chats.Split('\n');
                    foreach (string l in lines)
                    {
                        if (l != "")
                        {
                            if (l[0] == '!')
                            {
                                line = $"""
                                <h2 class="contact-name">{l.Remove(0, 1)}</h2>
                                <div class="contact-actions">
                                    <form method="get" action="/Chat/{l.Remove(0, 1)}">
                                        <button class="matrix-btn" type="submit">💬 Написать</button>
                                    </form>
                                    <form method="post" action="/DelContact/{l.Remove(0, 1)}">
                                        <button class="matrix-btn" type="submit">🗑 Удалить</button>
                                    </form>
                                </div>
                                """;
                                html += line;
                                Check = false;
                            }
                        }
                    }
                }
            }
            if (Check)
            {
                html += line;
                i++;
            }
            Check = true;
        }
    }
    html += """</html>""";

    return Results.Content(html, "text/html; charset=utf-8");
});

app.MapPost("/DelContact/{name}", async (string name, HttpContext context, IHttpClientFactory factory, Db db) =>
{
    var client = factory.CreateClient("ApiClient");

    var us = await client.GetAsync($"/api/CheckNik/{name}");
    var us2 = await client.GetAsync($"/api/CheckNik/{User.Nik}");

    if (!us2.IsSuccessStatusCode || !us.IsSuccessStatusCode)
    {
        return;
    }

    var user = await us.Content.ReadFromJsonAsync<User>();
    var user2 = await us2.Content.ReadFromJsonAsync<User>();


    await DelContact(user!, db, User.Nik);
    await DelContact(user2!, db, name);

    SetUser(user2!);
    await db.SaveChangesAsync();
    Reset();
    context.Response.Redirect("/chats");
}); 

app.MapGet("/AddContact", () =>
{
    string html = File.ReadAllText("HTML\\AddContact.html");
    return Results.Content(html, "text/html; charset=utf-8");
});
app.MapPost("/AddContact", async (HttpContext context, IHttpClientFactory factory,Db db) =>
{
    var client = factory.CreateClient("ApiClient");
    string html = File.ReadAllText("HTML\\AddS.html");

    var form = await context.Request.ReadFormAsync();

    string nik = form["nik"]!;


    var us = await client.GetAsync($"/api/CheckNik/{nik}");
    var us2 = await client.GetAsync($"/api/CheckNik/{User.Nik}");



    if (!us2.IsSuccessStatusCode || !us.IsSuccessStatusCode)
    {
        html = File.ReadAllText("HTML\\AddError.html");
        return Results.Content(html, "text/html; charset=utf-8");
    }

    var user = await us.Content.ReadFromJsonAsync<User>();
    var user2 = await us2.Content.ReadFromJsonAsync<User>();

    string[] lines = User.Chats.Split('\n');
    foreach (string l in lines)
    {
        if (l != "")
        {
            if (l[0] == '!')
            {
                if (l.Remove(0, 1) == nik)
                {
                    html = File.ReadAllText("HTML\\AddError2.html");
                    return Results.Content(html, "text/html; charset=utf-8");
                }
            }
        }
    }

    await AddContact(user!, db, User.Nik);
    await AddContact(user2!, db, nik);

    SetUser(user2!);
    await db.SaveChangesAsync();

    return Results.Content(html, "text/html; charset=utf-8");
});

app.MapPost("/Save", async (IHttpClientFactory factory, HttpContext context, Db db) =>
{
    var client = factory.CreateClient("ApiClient");

    var us = await client.GetAsync($"/api/CheckNik/{u.user2}");
    var us2 = await client.GetAsync($"/api/CheckNik/{User.Nik}");

    if (!us2.IsSuccessStatusCode || !us.IsSuccessStatusCode)
    {
        return;
    }

    var user = await us.Content.ReadFromJsonAsync<User>();
    var user2 = await us2.Content.ReadFromJsonAsync<User>();

    await SaveMessages(user!, db, user2!.Nik);
    await SaveMessages(user2!, db, user!.Nik);
    await db.SaveChangesAsync();

    var us3 = await client.GetAsync($"/api/CheckNik/{user2.Nik}");
    if (!us3.IsSuccessStatusCode)
    {
        return;
    }
    var user3 = await us3.Content.ReadFromJsonAsync<User>();
    SetUser(user3!);

    Reset();

    context.Response.Redirect("/Chats");
});

app.MapGet("/Chat/{name}", async (string name, HttpContext context) => 
{
    Messages = string.Empty;
    Reset();
    Nik = name;
    u.user2 = name;
    var html = string.Empty;
    string line, messages = string.Empty;
    string[] chat = User.Chats.Split("\n");

    GetIndex();

    using (StreamReader sr = new StreamReader($"HTML\\Socket.html"))
    {
        while ((line = sr.ReadLine()!) != null)
        {
            if(line.Trim() == "<p>Работа сокета</p>")
            {
                line = $"<p id=\"userNik\">{User.Nik}</p>";
            }
            if (line.Trim() == "<textarea readonly class=\"form-control matrix-textarea\" id=\"all_message\" rows=\"8\" placeholder=\"&#187; Сообщения появятся здесь... | Матрица ожидает входящих данных\"></textarea>")
            {
                line = $"<textarea readonly class=\"form-control matrix-textarea\" id=\"all_message\" rows=\"8\" placeholder=\"&#187; Сообщения появятся здесь... | Матрица ожидает входящих данных\">{User.Messages[Index]}</textarea>";
            }
            html += line;
        }
    }

    return Results.Content(html, "text/html; charset=utf-8");
});

app.Map("/ws", async context =>
{
    if (!context.WebSockets.IsWebSocketRequest)
    {
        context.Response.StatusCode = StatusCodes.Status400BadRequest;
        await context.Response.WriteAsync("Expected a WebSocket request.");
        return;
    }

    using var webSocket = await context.WebSockets.AcceptWebSocketAsync();
    var id = Guid.NewGuid();
    sockets.TryAdd(id, webSocket);
    await HandleWebSocketConnection(webSocket);
    sockets.TryRemove(id, out _);
});


await app.RunAsync();

static string GetHash(string input)
{
    using var sha = SHA256.Create();
    byte[] bytes = Encoding.UTF8.GetBytes(input);
    byte[] hashBytes = sha.ComputeHash(bytes);

    var sb = new StringBuilder();
    foreach (byte b in hashBytes)
        sb.Append(b.ToString("x2"));

    return sb.ToString();
}
static async Task CreateTables(Db db) 
{
    await db.Database.ExecuteSqlRawAsync("""
        CREATE TABLE IF NOT EXISTS "Users" (
            "Id" integer GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
            "Nik" text NOT NULL,
            "Login" text NOT NULL,
            "Password" text NOT NULL,
            "Chats" NVARCHAR(MAX),
            "Messages" TEXT[] NULL
        );
        """);
}

static void CreateCookie(string login, string password, HttpContext context)
{
    context.Response.Cookies.Append("Session_id", $"{login}:{password}", new CookieOptions
    {
        Expires = DateTimeOffset.Now.AddDays(30),
        Secure = true,
        HttpOnly = true
    });
}
static void DeleteCookie(HttpContext context)
{
    context.Response.Cookies.Delete("Session_id");
}
void SetUser(User us)
{
    User = us;
    Class.User = us;
}

void GetIndex()
{
    if(User.Chats != "")
    {
        string[] lines = User.Chats.Split("\n");
        foreach (string l in lines)
        {
            Index++;
            if (l.Remove(0, 1) == Nik)
            {
                break;
            }
        }
    }
}

int GetIndex2(User u, string name)
{
    int index = -1;
    if (u.Chats != "")
    {
        string[] lines = u.Chats.Split("\n");
        foreach (string l in lines)
        {
            index++;
            if (l.Remove(0, 1) == name)
            {
                return index;
            }
        }
    }
    return -1;
}

async Task DelChat(User user, Db db, string nik)
{
    int index = GetIndex2(user, nik);

    if (user.Messages.Length == 1)
    {
        user.Messages[0] = "New";
    }
    else
    {
        user.Messages = user.Messages.Where(u => u != user.Messages[index]).ToArray();
    }
}

void Reset()
{
    Nik = string.Empty;
    Index = -1;
}

async Task AddContact(User user, Db db, string nik)
{
    user.Chats += $"!{nik}" + '\n';

    try
    {
        if (user.Messages[0] == "New")
        {
            user.Messages[0] = "Начните общение\n";
        }
        else
        {
            user.Messages = user.Messages.Append("Начните общение\n").ToArray();
        }
    }
    catch (IndexOutOfRangeException)
    {
        user.Messages = user.Messages.Append("Начните общение\n").ToArray();
    }
}

async Task DelContact(User user, Db db, string name)
{
    await DelChat(user, db, name);
    string NewChat = string.Empty;
    string[] lines = user.Chats.Split('\n');
    foreach (string l in lines)
    {
        if (l != "")
        {
            if (l.Remove(0, 1) != name)
            {
                NewChat += l + '\n';
            }
        }
    }
    user.Chats = NewChat;
}

async Task SaveMessages(User user, Db db, string name)
{
    int index = GetIndex2(user, name);
    db.Users.Attach(user);
    user.Messages[index] += Messages;
}
static string CreateConnectionString(string ConnectionString)
{
    if (!ConnectionString.StartsWith("postgresql://", StringComparison.OrdinalIgnoreCase) &&
        !ConnectionString.StartsWith("postgres://", StringComparison.OrdinalIgnoreCase))
    {
        return ConnectionString;
    }

    var databaseUri = new Uri(ConnectionString);

    var userInfoParts = databaseUri.UserInfo.Split(':', 2, StringSplitOptions.None);

    if (userInfoParts.Length != 2)
    {
        throw new InvalidOperationException("Не удалось разобрать логин и пароль из URI-строки подключения PostgreSQL.");
    }

    var connectionStringBuilder = new NpgsqlConnectionStringBuilder
    {
        Host = databaseUri.Host,

        Port = databaseUri.IsDefaultPort ? 5432 : databaseUri.Port,

        Database = databaseUri.AbsolutePath.Trim('/'),

        Username = Uri.UnescapeDataString(userInfoParts[0]),

        Password = Uri.UnescapeDataString(userInfoParts[1])
    };

    foreach (var queryPart in databaseUri.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
    {
        var queryPartPieces = queryPart.Split('=', 2, StringSplitOptions.None);

        var key = Uri.UnescapeDataString(queryPartPieces[0]);

        var value = queryPartPieces.Length > 1
            ? Uri.UnescapeDataString(queryPartPieces[1])
            : string.Empty;

        if (key.Equals("sslmode", StringComparison.OrdinalIgnoreCase))
        {
            connectionStringBuilder["SSL Mode"] = value;

            continue;
        }

        if (key.Equals("channel_binding", StringComparison.OrdinalIgnoreCase))
        {
            connectionStringBuilder["Channel Binding"] = value;

            continue;
        }

        connectionStringBuilder[key] = value;
    }

    return connectionStringBuilder.ConnectionString;
}
public class User2 { public string user2 { get; set; } = string.Empty; }