﻿(function () {
    // Проверяем поддержку WebSocket
    if (!window.WebSocket) {
        const logArea = document.getElementById('all_message');
        if (logArea) logArea.value = "⚠️ [СИСТЕМА] Ваш браузер не поддерживает WebSocket.\nНевозможно установить матричное соединение.";
        return;
    }

    // Определяем WebSocket адрес (динамически, чтобы корректно работать локально и на хосте)
    let wsProtocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    let wsHost = window.location.host; // включает порт если есть
    let socketUrl = `${wsProtocol}//${wsHost}/ws`;   // стандартный путь для WebSocket (можно изменить под сервер)
    // Если нужен другой путь, то даём возможность, но оставляем /ws наиболее вероятным для сокетов
    // Но предусмотрим: если при запуске будет ошибка, то выведем в лог

    let socket = null;
    let reconnectAttempts = 0;
    const maxReconnect = 5;
    let reconnectTimeout = null;
    let linksFiles = null;

    const writeArea = document.getElementById('write_message');
    const allMessagesArea = document.getElementById('all_message');
    const sendBtn = document.getElementById('send_message');
    const styleArea = document.getElementById('TextStyle');
    const closeBtn = document.getElementById('close');
    const aiHelpBtn = document.getElementById('aiHelpBtn');
    const statusSpan = document.getElementById('connectionStatus');
    const files = document.getElementById('file');
    

    // Функция добавления сообщения в лог (с timestamp в матричном стиле)
    function addMessageToLog(msg, isSystem = false, isError = false) {
        if (!allMessagesArea) return;
        const timestamp = new Date().toLocaleTimeString('ru-RU', { hour12: false });
        let prefix = isSystem ? (isError ? "[⚡ СБОЙ]" : "[🧬 СИСТЕМА]") : "[📨 ПОЛУЧЕНО]";
        if (isSystem && !isError && msg.includes("Отправлено")) prefix = "[📡 ОТПРАВЛЕНО]";
        else if (!isSystem && msg.startsWith(">> Отправлено:")) prefix = "[✅ ЭХО]";

        const formattedMsg = `[${timestamp}] ${prefix} ${msg}`;
        const current = allMessagesArea.value;
        allMessagesArea.value = current ? current + "\n" + formattedMsg : formattedMsg;
        // автоскролл вниз
        allMessagesArea.scrollTop = allMessagesArea.scrollHeight;
    }

    // Обновление статуса
    function updateStatus(connected) {
        if (statusSpan) {
            if (connected) {
                statusSpan.innerHTML = "🟢 СОЕДИНЕНИЕ АКТИВНО";
                statusSpan.style.color = "#aaffcc";
            } else {
                statusSpan.innerHTML = "🔴 РАЗОРВАН / ОЖИДАНИЕ";
                statusSpan.style.color = "#ffaa88";
            }
        }
    }

    // Подключение WebSocket
    function connectWebSocket() {
        if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
            return;
        }

        try {
            socket = new WebSocket(socketUrl);

            socket.onopen = function () {
                addMessageToLog("Канал передачи данных активирован. Соединение с матрицей установлено.", true);
                updateStatus(true);
                reconnectAttempts = 0;
                if (reconnectTimeout) clearTimeout(reconnectTimeout);
                // при успешном подключении можем отправить приветственный сигнал (опционально)
                // socket.send(JSON.stringify({type:"init", client:"matrix_ui"})); - если нужно
            };

            socket.onmessage = async function (event) {
                let message = event.data;

                // Пытаемся красиво отобразить JSON, но в любом случае показываем текст
                try {
                    const parsed = JSON.parse(message);
                    if (parsed.downloadUrls && Array.isArray(parsed.downloadUrls)) {
                        const formattedLinks = parsed.downloadUrls.join('\n');
                        message += (message.value ? '\n' : '') + formattedLinks;
                    }
                    if (parsed.message) message = parsed.message;
                    else if (parsed.text) message = parsed.text;
                    else message = JSON.stringify(parsed, null, 0);
                } catch (e) { /* оставляем как есть */ }
                addMessageToLog(message, false);
            };

            socket.onerror = function (error) {
                console.error("WebSocket ошибка:", error);
                addMessageToLog("Обнаружена ошибка канала связи. Попытка переподключения...", true, true);
                updateStatus(false);
            };

            socket.onclose = function (event) {
                let reason = (event.reason ? event.reason : "Неизвестная причина");
                addMessageToLog(`Соединение разорвано (код: ${event.code}) Причина: ${reason}. Переподключение...`, true, true);
                updateStatus(false);
                // Переподключение с задержкой
                if (reconnectAttempts < maxReconnect) {
                    reconnectAttempts++;
                    const delay = Math.min(3000 * reconnectAttempts, 10000);
                    reconnectTimeout = setTimeout(() => {
                        connectWebSocket();
                    }, delay);
                } else {
                    addMessageToLog("❌ Превышено количество попыток переподключения. Обновите страницу вручную.", true, true);
                }
            };
        } catch (e) {
            addMessageToLog(`Критическая ошибка соединения: ${e.message}. Убедитесь что WebSocket сервер запущен на ${socketUrl}`, true, true);
            updateStatus(false);
        }
    }

    // Отправка сообщения
    async function sendMessage() {
        if (!writeArea) return;
        let data = null;
        const msg = writeArea.value.trim();
        if (!msg) {
            addMessageToLog("Невозможно отправить пустое сообщение. Введите данные.", true, true);
            return;
        }
        if (files) {
            const formData = new FormData();

            for (let i = 0; i < file.length; i++) {
                formData.append('files', files.files[i]);
            }
            const response = await fetch('/processingFile', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            linksFiles = data;
            socket.send(linksFiles);
        }
        if (!socket || socket.readyState !== WebSocket.OPEN) {
            addMessageToLog("Соединение потеряно. Пытаемся восстановить связь... Отправка отложена.", true, true);
            connectWebSocket();
            // после переподключения не отправится автоматически, но предложим повтор
            setTimeout(() => {
                if (socket && socket.readyState === WebSocket.OPEN) {
                    addMessageToLog("Соединение восстановлено, можете отправить сообщение повторно.", true);
                }
            }, 1500);
            return;
        }

        try {
            socket.send(msg);
            addMessageToLog(`Отправлено: ${msg.substring(0, 200)}${msg.length > 200 ? "..." : ""}`, true);
            writeArea.value = ""; // Очищаем поле после отправки
            writeArea.focus();
        } catch (err) {
            addMessageToLog(`Ошибка при отправке: ${err.message}`, true, true);
        }
    }

    async function showAIHelp() {
        const dataToSend = {
            text: allMessagesArea.value,
            style: styleArea.value
        };
        const response = await fetch('/remove_errors', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dataToSend)
        });
        const data = await response.json();
        allMessagesArea.value = data.Answer;
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', function (e) {
            if (socket && socket.readyState === WebSocket.OPEN) {
                addMessageToLog("Завершение сеанса. WebSocket будет закрыт.", true);
                socket.close(1000, "Пользователь нажал назад");
            }
        });
    }

    if (allMessagesArea) {
        allMessagesArea.addEventListener('dblclick', function () {
            if (confirm("🧹 Очистить весь лог сообщений?")) {
                allMessagesArea.value = "[ЛОГ ОЧИЩЕН] — Матрица готова к приёму новых данных.\n";
                addMessageToLog("История сообщений очищена пользователем.", true);
            }
        });
    }

    if (sendBtn) sendBtn.addEventListener('click', sendMessage);
    if (aiHelpBtn) aiHelpBtn.addEventListener('click', showAIHelp);

    if (writeArea) {
        writeArea.addEventListener('keydown', function (e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                sendMessage();
            }
        });
    }


    connectWebSocket();

    if (writeArea) {
        setInterval(() => {
            if (document.activeElement === writeArea) {
            }
        }, 100);
    }


    setTimeout(() => {
        if (!socket || socket.readyState !== WebSocket.OPEN) {
            addMessageToLog(`⚠️ ВНИМАНИЕ: WebSocket не смог подключиться к ${socketUrl}. Убедитесь, что сервер запущен и поддерживает путь /ws`, true, true);
        } else {
            addMessageToLog("✅ Готов к приёму и передаче. Матричный протокол активен.", true);
        }
    }, 800);
})();