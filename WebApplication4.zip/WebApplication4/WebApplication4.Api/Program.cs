using Npgsql;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins("http://localhost:5000", "https://localhost:7000")
              .AllowAnyMethod()
              .AllowAnyHeader());
});

var app = builder.Build();

app.UseCors();

string connectionString = builder.Configuration.GetConnectionString("NeonDb")!;

// ─── Ping ─────────────────────────────────────────────────────────────────────

app.MapGet("/api/ping", () => "API работает");

// ─── DB Test ──────────────────────────────────────────────────────────────────

app.MapGet("/api/db-test", async () =>
{
    try
    {
        await using var conn = new NpgsqlConnection(connectionString);
        await conn.OpenAsync();
        return Results.Ok("Подключение к базе данных успешно");
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка подключения: " + ex.Message);
    }
});

// ─── GET /api/products ────────────────────────────────────────────────────────

app.MapGet("/api/products", async () =>
{
    var products = new List<Product>();

    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand("SELECT id, name, price FROM products", conn);
    await using var reader = await cmd.ExecuteReaderAsync();

    while (await reader.ReadAsync())
    {
        products.Add(new Product
        {
            Id    = reader.GetInt32(0),
            Name  = reader.GetString(1),
            Price = reader.GetInt32(2)
        });
    }

    return Results.Ok(products);
});

// ─── GET /api/products/{id} ───────────────────────────────────────────────────

app.MapGet("/api/products/{id}", async (int id) =>
{
    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand("SELECT id, name, price FROM products WHERE id = @id", conn);
    cmd.Parameters.AddWithValue("id", id);

    await using var reader = await cmd.ExecuteReaderAsync();

    if (!await reader.ReadAsync())
        return Results.NotFound();

    return Results.Ok(new Product
    {
        Id    = reader.GetInt32(0),
        Name  = reader.GetString(1),
        Price = reader.GetInt32(2)
    });
});

// ─── POST /api/products ───────────────────────────────────────────────────────

app.MapPost("/api/products", async (CreateProductRequest request) =>
{
    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand(
        "INSERT INTO products (name, price) VALUES (@name, @price) RETURNING id", conn);
    cmd.Parameters.AddWithValue("name",  request.Name);
    cmd.Parameters.AddWithValue("price", request.Price);

    var newId = (int)(await cmd.ExecuteScalarAsync())!;

    var created = new Product { Id = newId, Name = request.Name, Price = request.Price };
    return Results.Created($"/api/products/{newId}", created);
});

// ─── PUT /api/products/{id} ───────────────────────────────────────────────────

app.MapPut("/api/products/{id}", async (int id, UpdateProductRequest request) =>
{
    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand(
        "UPDATE products SET name = @name, price = @price WHERE id = @id", conn);
    cmd.Parameters.AddWithValue("name",  request.Name);
    cmd.Parameters.AddWithValue("price", request.Price);
    cmd.Parameters.AddWithValue("id",    id);

    int rows = await cmd.ExecuteNonQueryAsync();

    if (rows == 0)
        return Results.NotFound();

    return Results.Ok(new Product { Id = id, Name = request.Name, Price = request.Price });
});

// ─── DELETE /api/products/{id} ────────────────────────────────────────────────

app.MapDelete("/api/products/{id}", async (int id) =>
{
    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand("DELETE FROM products WHERE id = @id", conn);
    cmd.Parameters.AddWithValue("id", id);

    int rows = await cmd.ExecuteNonQueryAsync();

    if (rows == 0)
        return Results.NotFound();

    return Results.NoContent();
});

app.Run();

// ─── Модели ───────────────────────────────────────────────────────────────────

class Product
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public int Price { get; set; }
}

class CreateProductRequest
{
    public string Name { get; set; } = "";
    public int Price { get; set; }
}

class UpdateProductRequest
{
    public string Name { get; set; } = "";
    public int Price { get; set; }
}
