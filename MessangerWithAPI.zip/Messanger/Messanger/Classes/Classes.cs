﻿namespace Messanger.Classes
{
    public class User
    {
        public int Id { get; set; }
        public string Nik { get; set; } = string.Empty;
        public string Login { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Chats { get; set; } = string.Empty;
        public string[] Messages { get; set; } = Array.Empty<string>();
    }
    public record class AddUser(string Nik, string Login, string Password);
    public record class LogPass(string Login, string Password);
}
