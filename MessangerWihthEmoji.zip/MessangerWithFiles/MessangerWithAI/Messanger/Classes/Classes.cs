﻿using Messanger.Tabels;
using Microsoft.AspNetCore.StaticFiles;
using System.Security.Cryptography;
using System.Text.Json;

namespace Messanger.Classes
{
    public class User
    {
        public int Id { get; set; }
        public string Nik { get; set; } = string.Empty;
        public string Login { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string Chats { get; set; } = string.Empty;
        public string[] Messages { get; set; } = Array.Empty<string>();
    }

    public class User2 { public string user2 { get; set; } = string.Empty; }
    public record class AddUser(string Nik, string Login, string Password);
    public record class LogPass(string Login, string Password);
    public record class TextData(string Text);
    public record class GigaChatRequest(string Promt);
    public record class GigaChatResponse(string Answer);
    public record RegisterRequestDto(string Login, string Nik, string Password);
    public record LoginRequestDto(string Login, string Password);
    public record class MessageWithFilesJson(string Type, string Text, List<string> Files, long createdAt);

    class GigaChatService
    {
        private readonly IHttpClientFactory _factory;
        private readonly string _authorizationKey;
        private readonly string _scope;

        private string? _accessToken;
        private DateTimeOffset _tokenExpiresAt = DateTimeOffset.MinValue;

        public GigaChatService(IHttpClientFactory factory, IConfiguration config)
        {
            _factory = factory;
            _authorizationKey = config["GigaChat:AuthorizationKey"]!;
            _scope = config["GigaChat:Scope"]!;
        }

        public async Task<string> AskAsync(string prompt)
        {
            string token = await GetAccessTokenAsync();

            var client = _factory.CreateClient("GigaChat");

            var requestBody = new
            {
                model = "GigaChat",
                messages = new[]
                {
                new { role = "user", content = prompt }
            }
            };

            using var message = new HttpRequestMessage(
                HttpMethod.Post,
                "https://gigachat.devices.sberbank.ru/api/v1/chat/completions");
            message.Headers.Add("Authorization", "Bearer " + token);
            message.Content = JsonContent.Create(requestBody);

            var response = await client.SendAsync(message);
            response.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            string answer = doc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString() ?? "";

            return answer;
        }
        private async Task<string> GetAccessTokenAsync()
        {
            if (_accessToken != null && DateTimeOffset.UtcNow < _tokenExpiresAt)
                return _accessToken;

            var client = _factory.CreateClient("GigaChat");

            using var message = new HttpRequestMessage(
                HttpMethod.Post,
                "https://ngw.devices.sberbank.ru:9443/api/v2/oauth");
            message.Headers.Add("Authorization", "Basic " + _authorizationKey);
            message.Headers.Add("RqUID", Guid.NewGuid().ToString());
            message.Content = new FormUrlEncodedContent(new[]
            {
            new KeyValuePair<string, string>("scope", _scope)
        });

            var response = await client.SendAsync(message);
            response.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            var root = doc.RootElement;

            _accessToken = root.GetProperty("access_token").GetString();
            long expiresAtMs = root.GetProperty("expires_at").GetInt64();
            _tokenExpiresAt = DateTimeOffset.FromUnixTimeMilliseconds(expiresAtMs).AddMinutes(-1);

            return _accessToken!;
        }
    }
    public class Contact
    {
        private int GetContactIndex(User u, string name)
        {
            int index = -1;
            if (u.Chats != "")
            {
                string[] lines = u.Chats.Split("\n");
                foreach (string l in lines)
                {
                    index++;
                    if (l.Remove(0, 1) == name)
                    {
                        return index;
                    }
                }
            }
            return -1;
        }
        public async Task AddContact(User user, Db db, string nik)
        {
            user.Chats += $"!{nik}" + '\n';

            try
            {
                if (user.Messages[0] == "New")
                {
                    user.Messages[0] = "Начните общение\n";
                }
                else
                {
                    user.Messages = user.Messages.Append("Начните общение\n").ToArray();
                }
            }
            catch (IndexOutOfRangeException)
            {
                user.Messages = user.Messages.Append("Начните общение\n").ToArray();
            }
        }

        public async Task DelContact(User user, Db db, string name)
        {
            await DelChat(user, db, name);
            string NewChat = string.Empty;
            string[] lines = user.Chats.Split('\n');
            foreach (string l in lines)
            {
                if (l != "")
                {
                    if (l.Remove(0, 1) != name)
                    {
                        NewChat += l + '\n';
                    }
                }
            }
            user.Chats = NewChat;
        }

        private async Task DelChat(User user, Db db, string nik)
        {
            int index = GetContactIndex(user, nik);

            if (user.Messages.Length == 1)
            {
                user.Messages[0] = "New";
            }
            else
            {
                user.Messages = user.Messages.Where(u => u != user.Messages[index]).ToArray();
            }
        }
    }

    public class CookieFiles
    {
        public static void CreateCookie(string login, string password, HttpContext context)
        {
            context.Response.Cookies.Append("Session_id", $"{login}:{password}", new CookieOptions
            {
                Expires = DateTimeOffset.Now.AddDays(30),
                Secure = true,
                HttpOnly = true
            });
        }
        public static void DeleteCookie(HttpContext context)
        {
            context.Response.Cookies.Delete("Session_id");
        }
    }
    public static class WorkWithFiles
    {
        public async static Task<string> CheckedFolder(WebApplication app)
        {
            string uploadsFolder = Path.Combine(app.Environment.ContentRootPath, "UploadedFiles");
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            return uploadsFolder;
        }

        public async static Task<IResult> ProcessingFile(WebApplicationBuilder builder, HttpRequest request, string uploadsFolder)
        {
            string? keyString = builder.Configuration["FileEncryption:Key"];
            string? ivString = builder.Configuration["FileEncryption:IV"];
            var form = await request.ReadFormAsync();
            var files = form.Files;

            if (string.IsNullOrEmpty(keyString) || string.IsNullOrEmpty(ivString))
            {
                throw new InvalidOperationException("Ключи шифрования не найдены в конфигурации!");
            }
            byte[] encryptionKey = Convert.FromBase64String(keyString);
            byte[] encryptionIv = Convert.FromBase64String(ivString);


            if (files == null || files.Count == 0)
                return Results.BadRequest("Файлы не загружены");

            var downloadUrls = new List<string>();

            try
            {
                foreach (var file in files)
                {
                    if (file.Length == 0) continue;

                    var uniqueFileName = $"{Guid.NewGuid()}_{file.FileName}";
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (Aes aes = Aes.Create())
                    {
                        aes.Key = encryptionKey;
                        aes.IV = encryptionIv;

                        using var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                        using var encryptor = aes.CreateEncryptor();
                        using var cryptoStream = new CryptoStream(fileStream, encryptor, CryptoStreamMode.Write);

                        await file.CopyToAsync(cryptoStream);
                    }
                    var downloadUrl = $"{request.Scheme}://{request.Host}/api/download/{uniqueFileName}";
                    downloadUrls.Add(downloadUrl);
                }
                return Results.Ok(new { DownloadUrls = downloadUrls });
            }
            catch (Exception ex)
            {
                return Results.BadRequest(ex.Message);
            }
        }

        public async static Task<IResult> DownloadFiles(WebApplicationBuilder builder, string uploadsFolder, string fileName)
        {
            string? keyString = builder.Configuration["FileEncryption:Key"];
            string? ivString = builder.Configuration["FileEncryption:IV"];

            if (string.IsNullOrEmpty(keyString) || string.IsNullOrEmpty(ivString))
            {
                throw new InvalidOperationException("Ключи шифрования не найдены в конфигурации!");
            }
            byte[] encryptionKey = Convert.FromBase64String(keyString);
            byte[] encryptionIv = Convert.FromBase64String(ivString);

            var filePath = Path.Combine(uploadsFolder, fileName);
            if (!File.Exists(filePath)) return Results.NotFound("Файл не найден");

            var provider = new FileExtensionContentTypeProvider();
            if (!provider.TryGetContentType(filePath, out var contentType))
            {
                contentType = "application/octet-stream";
            }

            Aes aes = Aes.Create();
            aes.Key = encryptionKey;
            aes.IV = encryptionIv;
            var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            var decryptor = aes.CreateDecryptor();

            var cryptoStream = new CryptoStream(fileStream, decryptor, CryptoStreamMode.Read);

            var originalName = fileName.Substring(fileName.IndexOf('_') + 1);

            return Results.File(cryptoStream, contentType, originalName);

        }
    }
}
