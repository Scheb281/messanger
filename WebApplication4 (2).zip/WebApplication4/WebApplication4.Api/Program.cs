using System.Net.Http.Json;
using System.Text.Json;
using Npgsql;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins("http://localhost:5000", "https://localhost:7000")
              .AllowAnyMethod()
              .AllowAnyHeader());
});

// HttpClient для GigaChat.
// ВАЖНО: у серверов GigaChat сертификат НУЦ Минцифры, которого нет в доверенных по умолчанию.
// Для учебного проекта отключаем проверку SSL. В реальном проекте так делать нельзя —
// нужно установить корневой сертификат Минцифры.
builder.Services.AddHttpClient("GigaChat")
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
    });

// Регистрируем сервис GigaChat как singleton, чтобы access token переиспользовался между запросами
builder.Services.AddSingleton<GigaChatService>();

var app = builder.Build();

app.UseCors();

string connectionString = builder.Configuration.GetConnectionString("NeonDb")!;

// ─── GigaChat ─────────────────────────────────────────────────────────────────

// POST /api/gigachat — принимает текст вопроса, возвращает ответ от GigaChat
app.MapPost("/api/gigachat", async (GigaChatRequest request, GigaChatService giga) =>
{
    try
    {
        string answer = await giga.AskAsync(request.Prompt);
        return Results.Ok(new GigaChatResponse { Answer = answer });
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка GigaChat: " + ex.Message);
    }
});

// ─── Ping ─────────────────────────────────────────────────────────────────────

app.MapGet("/api/ping", () => "API работает");

// ─── DB Test ──────────────────────────────────────────────────────────────────

app.MapGet("/api/db-test", async () =>
{
    try
    {
        await using var conn = new NpgsqlConnection(connectionString);
        await conn.OpenAsync();
        return Results.Ok("Подключение к базе данных успешно");
    }
    catch (Exception ex)
    {
        return Results.Problem("Ошибка подключения: " + ex.Message);
    }
});

// ─── GET /api/products ────────────────────────────────────────────────────────

app.MapGet("/api/products", async () =>
{
    var products = new List<Product>();

    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand("SELECT id, name, price FROM products", conn);
    await using var reader = await cmd.ExecuteReaderAsync();

    while (await reader.ReadAsync())
    {
        products.Add(new Product
        {
            Id    = reader.GetInt32(0),
            Name  = reader.GetString(1),
            Price = reader.GetInt32(2)
        });
    }

    return Results.Ok(products);
});

// ─── GET /api/products/{id} ───────────────────────────────────────────────────

app.MapGet("/api/products/{id}", async (int id) =>
{
    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand("SELECT id, name, price FROM products WHERE id = @id", conn);
    cmd.Parameters.AddWithValue("id", id);

    await using var reader = await cmd.ExecuteReaderAsync();

    if (!await reader.ReadAsync())
        return Results.NotFound();

    return Results.Ok(new Product
    {
        Id    = reader.GetInt32(0),
        Name  = reader.GetString(1),
        Price = reader.GetInt32(2)
    });
});

// ─── POST /api/products ───────────────────────────────────────────────────────

app.MapPost("/api/products", async (CreateProductRequest request) =>
{
    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand(
        "INSERT INTO products (name, price) VALUES (@name, @price) RETURNING id", conn);
    cmd.Parameters.AddWithValue("name",  request.Name);
    cmd.Parameters.AddWithValue("price", request.Price);

    var newId = (int)(await cmd.ExecuteScalarAsync())!;

    var created = new Product { Id = newId, Name = request.Name, Price = request.Price };
    return Results.Created($"/api/products/{newId}", created);
});

// ─── PUT /api/products/{id} ───────────────────────────────────────────────────

app.MapPut("/api/products/{id}", async (int id, UpdateProductRequest request) =>
{
    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand(
        "UPDATE products SET name = @name, price = @price WHERE id = @id", conn);
    cmd.Parameters.AddWithValue("name",  request.Name);
    cmd.Parameters.AddWithValue("price", request.Price);
    cmd.Parameters.AddWithValue("id",    id);

    int rows = await cmd.ExecuteNonQueryAsync();

    if (rows == 0)
        return Results.NotFound();

    return Results.Ok(new Product { Id = id, Name = request.Name, Price = request.Price });
});

// ─── DELETE /api/products/{id} ────────────────────────────────────────────────

app.MapDelete("/api/products/{id}", async (int id) =>
{
    await using var conn = new NpgsqlConnection(connectionString);
    await conn.OpenAsync();

    await using var cmd = new NpgsqlCommand("DELETE FROM products WHERE id = @id", conn);
    cmd.Parameters.AddWithValue("id", id);

    int rows = await cmd.ExecuteNonQueryAsync();

    if (rows == 0)
        return Results.NotFound();

    return Results.NoContent();
});

app.Run();

// ─── Сервис GigaChat ──────────────────────────────────────────────────────────

// Инкапсулирует всю работу с GigaChat: авторизацию и отправку вопроса.
class GigaChatService
{
    private readonly IHttpClientFactory _factory;
    private readonly string _authorizationKey;
    private readonly string _scope;

    // Кэш access token. GigaChat выдаёт токен на 30 минут — не запрашиваем его каждый раз.
    private string? _accessToken;
    private DateTimeOffset _tokenExpiresAt = DateTimeOffset.MinValue;

    public GigaChatService(IHttpClientFactory factory, IConfiguration config)
    {
        _factory = factory;
        _authorizationKey = config["GigaChat:AuthorizationKey"]!;
        _scope = config["GigaChat:Scope"]!;
    }

    // Главный метод: задать вопрос и получить ответ
    public async Task<string> AskAsync(string prompt)
    {
        string token = await GetAccessTokenAsync();

        var client = _factory.CreateClient("GigaChat");

        var requestBody = new
        {
            model = "GigaChat",
            messages = new[]
            {
                new { role = "user", content = prompt }
            }
        };

        using var message = new HttpRequestMessage(
            HttpMethod.Post,
            "https://gigachat.devices.sberbank.ru/api/v1/chat/completions");
        message.Headers.Add("Authorization", "Bearer " + token);
        message.Content = JsonContent.Create(requestBody);

        var response = await client.SendAsync(message);
        response.EnsureSuccessStatusCode();

        // Разбираем ответ: choices[0].message.content
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        string answer = doc.RootElement
            .GetProperty("choices")[0]
            .GetProperty("message")
            .GetProperty("content")
            .GetString() ?? "";

        return answer;
    }

    // Меняем Authorization key на access token (действует 30 минут)
    private async Task<string> GetAccessTokenAsync()
    {
        // Если токен ещё живой — возвращаем закэшированный
        if (_accessToken != null && DateTimeOffset.UtcNow < _tokenExpiresAt)
            return _accessToken;

        var client = _factory.CreateClient("GigaChat");

        using var message = new HttpRequestMessage(
            HttpMethod.Post,
            "https://ngw.devices.sberbank.ru:9443/api/v2/oauth");
        message.Headers.Add("Authorization", "Basic " + _authorizationKey);
        message.Headers.Add("RqUID", Guid.NewGuid().ToString());   // уникальный id запроса — требование API
        message.Content = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("scope", _scope)
        });

        var response = await client.SendAsync(message);
        response.EnsureSuccessStatusCode();

        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var root = doc.RootElement;

        _accessToken = root.GetProperty("access_token").GetString();
        // expires_at приходит в миллисекундах Unix-времени; берём с запасом в 1 минуту
        long expiresAtMs = root.GetProperty("expires_at").GetInt64();
        _tokenExpiresAt = DateTimeOffset.FromUnixTimeMilliseconds(expiresAtMs).AddMinutes(-1);

        return _accessToken!;
    }
}

// ─── Модели ───────────────────────────────────────────────────────────────────

class GigaChatRequest
{
    public string Prompt { get; set; } = "";
}

class GigaChatResponse
{
    public string Answer { get; set; } = "";
}

class Product
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public int Price { get; set; }
}

class CreateProductRequest
{
    public string Name { get; set; } = "";
    public int Price { get; set; }
}

class UpdateProductRequest
{
    public string Name { get; set; } = "";
    public int Price { get; set; }
}
