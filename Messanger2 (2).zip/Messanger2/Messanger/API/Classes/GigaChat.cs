﻿using System.Text.Json;

namespace API.Classes
{
    class GigaChatService
    {
        private readonly IHttpClientFactory _factory;
        private readonly string _authorizationKey;
        private readonly string _scope;

        // Кэш access token. GigaChat выдаёт токен на 30 минут — не запрашиваем его каждый раз.
        private string? _accessToken;
        private DateTimeOffset _tokenExpiresAt = DateTimeOffset.MinValue;

        public GigaChatService(IHttpClientFactory factory, IConfiguration config)
        {
            _factory = factory;
            _authorizationKey = config["GigaChat:AuthorizationKey"]!;
            _scope = config["GigaChat:Scope"]!;
        }

        // Главный метод: задать вопрос и получить ответ
        public async Task<string> AskAsync(string prompt)
        {
            string token = await GetAccessTokenAsync();

            var client = _factory.CreateClient("GigaChat");

            var requestBody = new
            {
                model = "GigaChat",
                messages = new[]
                {
                new { role = "user", content = prompt }
            }
            };

            using var message = new HttpRequestMessage(
                HttpMethod.Post,
                "https://gigachat.devices.sberbank.ru/api/v1/chat/completions");
            message.Headers.Add("Authorization", "Bearer " + token);
            message.Content = JsonContent.Create(requestBody);

            var response = await client.SendAsync(message);
            response.EnsureSuccessStatusCode();

            // Разбираем ответ: choices[0].message.content
            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            string answer = doc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString() ?? "";

            return answer;
        }

        // Меняем Authorization key на access token (действует 30 минут)
        private async Task<string> GetAccessTokenAsync()
        {
            // Если токен ещё живой — возвращаем закэшированный
            if (_accessToken != null && DateTimeOffset.UtcNow < _tokenExpiresAt)
                return _accessToken;

            var client = _factory.CreateClient("GigaChat");

            using var message = new HttpRequestMessage(
                HttpMethod.Post,
                "https://ngw.devices.sberbank.ru:9443/api/v2/oauth");
            message.Headers.Add("Authorization", "Basic " + _authorizationKey);
            message.Headers.Add("RqUID", Guid.NewGuid().ToString());   // уникальный id запроса — требование API
            message.Content = new FormUrlEncodedContent(new[]
            {
            new KeyValuePair<string, string>("scope", _scope)
        });

            var response = await client.SendAsync(message);
            response.EnsureSuccessStatusCode();

            using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
            var root = doc.RootElement;

            _accessToken = root.GetProperty("access_token").GetString();
            // expires_at приходит в миллисекундах Unix-времени; берём с запасом в 1 минуту
            long expiresAtMs = root.GetProperty("expires_at").GetInt64();
            _tokenExpiresAt = DateTimeOffset.FromUnixTimeMilliseconds(expiresAtMs).AddMinutes(-1);

            return _accessToken!;
        }
    }
}
